package com.shopping.item;

import com.shopping.constants.Constant;

import java.util.Arrays;

public enum IsItemInPromotion {

    ITEM1("A",true,10.00, Constant.HALF_PRICE_PROMOTION),
    ITEM2("B",false,10.00,null),
    ITEM3("X",true,10.00,Constant.FREE_ITEMS_PROMOTION),
    ITEM4("Y",true,5.00,Constant.FREE_ITEMS_PROMOTION),
    ITEM5("Z",false,4.00,null),
    ITEM6("P",true,3.00,null),
    ITEM7("Q",false,8.00,null),
    ITEM8("R",false,2.00,null);

    private final String itemName;
    private final Boolean isPromotionItem;
    private final Double price;
    private String couponType;

    IsItemInPromotion(String itemName, Boolean isPromotionItem, Double price,String couponType) {
        this.itemName = itemName;
        this.isPromotionItem = isPromotionItem;
        this.price = price;
        this.couponType = couponType;
    }

    public Boolean isPromotionItem() {
        return isPromotionItem;
    }

    public Double getPrice() {
        return price;
    }

    public String getCouponType() {
        return couponType;
    }

    public void setCouponType(String couponType) {
        this.couponType = couponType;
    }

    public String getItemName() {
        return itemName;
    }

    public static Product findByItemName(final Item cartItem){
        IsItemInPromotion itemInfo =  Arrays.stream(values()).filter(value -> value.getItemName().equals(cartItem.getName())).findFirst().orElse(null);
        return new Product(itemInfo.getPrice(),itemInfo.getItemName(),itemInfo.isPromotionItem(),itemInfo.getCouponType());
    }
}
