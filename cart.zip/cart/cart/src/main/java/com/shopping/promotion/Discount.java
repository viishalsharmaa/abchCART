package com.shopping.promotion;

public interface Discount {

    double applyDiscount();
}
