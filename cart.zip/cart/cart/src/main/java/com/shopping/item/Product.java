package com.shopping.item;

public class Product implements Item {


    private double unitPrice;
    private String name;
    private Boolean isPromotionItem;
    private String couponType;

    public Product(double unitPrice, String name,Boolean isPromotionItem,String couponType) {
        this.unitPrice = unitPrice;
        this.name = name;
        this.isPromotionItem = isPromotionItem;
        this.couponType = couponType;
    }

    public Product(String name) {
        this.name = name;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean isPromotionItem() {
        return isPromotionItem;
    }

    public void setPromotionItem(Boolean promotionItem) {
        isPromotionItem = promotionItem;
    }

    public String getCouponType() {
        return couponType;
    }

    public void setCouponType(String couponType) {
        this.couponType = couponType;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double value() {
        return unitPrice;
    }

}

