package com.shopping.cart;

import com.shopping.constants.Constant;
import com.shopping.item.IsItemInPromotion;
import com.shopping.item.Item;
import com.shopping.item.Product;
import com.shopping.promotion.Discount;
import com.shopping.promotion.FreeItemPromotion;
import com.shopping.promotion.HalfPricePromotion;

import java.util.*;

public class CartCheckout {
        List<Item> cartItemList;
        Map<String, Integer> promotionCodeMap = new LinkedHashMap<>();


    public CartCheckout() {
            cartItemList = new ArrayList<>();
        }

        public void add(Item cartItem) {
            cartItemList.add(cartItem);
        }

        private Discount getDiscountStrategy(Product product) {
            if (product.getCouponType() == Constant.FREE_ITEMS_PROMOTION) {
                promotionCodeMap.put(Constant.FREE_ITEMS_PROMOTION,promotionCodeMap.getOrDefault(Constant.FREE_ITEMS_PROMOTION, 0)+1);
                return new FreeItemPromotion(product);
            }
            else {
                promotionCodeMap.put(Constant.HALF_PRICE_PROMOTION,promotionCodeMap.getOrDefault(Constant.HALF_PRICE_PROMOTION, 0)+1);
                return new HalfPricePromotion(product);
            }
        }


    private void addCoupon(Product product) {
        if (product.getCouponType() == Constant.FREE_ITEMS_PROMOTION) {
            promotionCodeMap.put(Constant.FREE_ITEMS_PROMOTION,promotionCodeMap.getOrDefault(Constant.FREE_ITEMS_PROMOTION, 0)+1);
//            return new FreeItemPromotion(product);
        }
        else {
            promotionCodeMap.put(Constant.HALF_PRICE_PROMOTION,promotionCodeMap.getOrDefault(Constant.HALF_PRICE_PROMOTION, 0)+1);
//            return new HalfPricePromotion(product);
        }
    }

        private double checkout() {
          Map<String, Integer> productMap = new LinkedHashMap<>();
            double total = 0;
            Iterator<Item> itemIterator = cartItemList.listIterator();
            while(itemIterator.hasNext()) {
                Product itemInfo = IsItemInPromotion.findByItemName(itemIterator.next());
                if(itemInfo.isPromotionItem()) {
                    productMap.put(itemInfo.getName(), productMap.getOrDefault(itemInfo.getName(), 0)+1);
                    promotionCodeMap.put(itemInfo.getCouponType(), promotionCodeMap.getOrDefault(itemInfo.getCouponType(), 0)+1);
                    //double discountedPrice = getDiscountStrategy(itemInfo).applyDiscount();
                    //total = total+discountedPrice;
//                } else{
//                    productMap.put(itemInfo.getName(), productMap.getOrDefault(itemInfo.getName(), 0)+1);
//                }
                total += itemInfo.value();
            }
            return total;
        }

        public static void main(String[] args) {
            CartCheckout cart = new CartCheckout();
            cart.add(new Product("A"));
            cart.add(new Product("A"));
            cart.add(new Product("A"));
            cart.add(new Product("A"));
            cart.add(new Product("A"));
            cart.add(new Product("A"));
            cart.add(new Product("B"));
            System.out.println(cart.checkout());
        }

    }

