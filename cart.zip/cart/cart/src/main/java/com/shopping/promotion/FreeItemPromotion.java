package com.shopping.promotion;

import com.shopping.item.Product;

import java.util.LinkedHashMap;
import java.util.Map;

public class FreeItemPromotion implements Discount {


    private Product product;

    public FreeItemPromotion(Product product) {
        this.product = product;
    }

    @Override
    public double applyDiscount() {
        Map<Product, Integer> productMap = new LinkedHashMap<>();
        Product no = productMap.keySet().stream().filter((x)-> x.isPromotionItem()==true).
                min((x,y)-> (int) x.getUnitPrice()).get();

        return 0;
    }
}
