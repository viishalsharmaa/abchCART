package com.shopping.promotion;

import com.shopping.item.Product;

public class HalfPricePromotion  implements Discount{


    private Product product;

    public HalfPricePromotion(Product product) {
        this.product = product;
    }

    @Override
    public double applyDiscount() {
        return 0;
    }
}
