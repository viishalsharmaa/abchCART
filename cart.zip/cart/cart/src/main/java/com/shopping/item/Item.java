package com.shopping.item;

public interface Item {
    String getName();
    double value();
}
