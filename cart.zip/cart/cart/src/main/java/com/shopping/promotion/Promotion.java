package com.shopping.promotion;

public class Promotion {
        private  HalfPricePromotion halfPricePromotion;
        private  FreeItemPromotion freeItemPromotion;

    public HalfPricePromotion getHalfPricePromotion() {
        return halfPricePromotion;
    }

    public void setHalfPricePromotion(HalfPricePromotion halfPricePromotion) {
        this.halfPricePromotion = halfPricePromotion;
    }

    public FreeItemPromotion getFreeItemPromotion() {
        return freeItemPromotion;
    }

    public void setFreeItemPromotion(FreeItemPromotion freeItemPromotion) {
        this.freeItemPromotion = freeItemPromotion;
    }
}

