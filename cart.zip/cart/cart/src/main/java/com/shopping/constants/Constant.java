package com.shopping.constants;

public class Constant {

        public static final String FREE_ITEMS_PROMOTION = "FreeItemPromotion";
        public static final String HALF_PRICE_PROMOTION = "HalfItemPromotion";
        private Constant() { }
    }

